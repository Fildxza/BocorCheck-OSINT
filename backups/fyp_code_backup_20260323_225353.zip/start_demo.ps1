$ErrorActionPreference = "Stop"

Set-Location $PSScriptRoot

$py = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) {
    Write-Host "[ERROR] Python venv not found at .venv\\Scripts\\python.exe"
    Write-Host "Run: py -3.11 -m venv .venv"
    exit 1
}

# Demo runtime settings
$env:USE_MOCK_DATA = "true"
$env:ENABLE_DB_LOGGING = "true"
$env:MYSQL_HOST = "127.0.0.1"
$env:MYSQL_PORT = "3306"
$env:MYSQL_USER = "fyp_user"
$env:MYSQL_PASSWORD = "Admin123!"
$env:MYSQL_DATABASE = "fyp_osint"
$env:FLASK_SECRET_KEY = "local-dev-secret"
$env:PHONE_DEFAULT_REGION = "MY"
$env:TELEGRAM_CHAT_ID = "5917103363"
$env:ADMIN_USERNAME = "admin"
$env:ADMIN_PASSWORD = "admin123"

Write-Host "[INFO] Starting OSINT web app on http://127.0.0.1:5000"
& $py app.py
